import { Platform } from "react-native";

// "Deep Current" palette: a dark ocean shell around light, high-contrast
// content cards. The app feels more like a dive product without forcing every
// form and data table into a fully dark theme.
export const colors = {
  // Dark ocean shell
  deepSea950: "#071D2B",
  deepSea900: "#0E3040",
  deepSea800: "#123C4E",
  deepSea700: "#18556D",
  deepSeaBorder: "#2B6072",

  // Text and icons used directly on dark ocean surfaces
  mist50: "#F6FBFC",
  mist200: "#D9E9EE",
  mist300: "#BCD2D9",
  mist400: "#91ADB7",

  // Core brand and light-surface text
  navy900: "#071D2B",
  navy700: "#0D3A50",
  ocean600: "#0B78A1",
  sky400: "#51B8DC",
  brick600: "#D44747",
  brick700: "#AE3030",

  gold500: "#F0C75E",
  gold700: "#75540B",
  goldBg: "#FBF0CE",

  // Light cards and controls stay readable against the dark shell.
  sand50: "#E9F3F6",
  sand100: "#D4E5EA",
  ink900: "#0A141B",
  slate600: "#3C5662",
  slate400: "#708C97",
  slate200: "#C1D5DC",
  white: "#F9FCFD",

  // Status
  success600: "#237A59",
  successBg: "#DDF2E8",
  warning600: "#9B6811",
  warningBg: "#F8EBCF",
  danger600: "#D44747",
  dangerBg: "#F8DFDF",
  neutralBg: "#E2EBEF",
} as const;

export const gradients = {
  oceanHeader: [colors.deepSea700, colors.navy700, colors.deepSea950] as const,
  ctaGlow: [colors.sky400, colors.ocean600] as const,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 40,
};

export const radii = {
  sm: 8,
  md: 12,
  lg: 20,
  pill: 999,
};

export const typography = {
  display: {
    fontWeight: "800" as const,
    letterSpacing: 0.6,
    textTransform: "uppercase" as const,
  },
  body: {
    fontWeight: "400" as const,
  },
  bodyMedium: {
    fontWeight: "600" as const,
  },
  readout: {
    fontVariant: ["tabular-nums"] as const,
  },
};

export const readoutFontFamily = Platform.select({
  ios: "Menlo",
  android: "monospace",
  default: "monospace",
});
